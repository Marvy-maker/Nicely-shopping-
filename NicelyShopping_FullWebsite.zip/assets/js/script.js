
// Live search
document.getElementById("searchInput").addEventListener("input", function () {
  let input = this.value.toLowerCase();
  document.querySelectorAll(".product-card").forEach(function (card) {
    card.style.display = card.textContent.toLowerCase().includes(input) ? "" : "none";
  });
});

// Category filter
document.getElementById("categoryFilter").addEventListener("change", function () {
  let selected = this.value;
  document.querySelectorAll(".product-card").forEach(function (card) {
    card.style.display = selected === "all" || card.dataset.category === selected ? "" : "none";
  });
});